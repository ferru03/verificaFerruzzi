package com.example;

/**
 * Hello world!
 *
 */
public class MainServer 
{
    public static void main( String[] args ){
        Server myServer = new Server();
        myServer.attendi();
        myServer.calcola();
    }
}
