package com.example;

/**
 * Hello world!
 *
 */
public class MainClient
{
    public static void main( String[] args ){
        Client myClient = new Client();
        myClient.connetti();
        myClient.comunica();
    }
}
