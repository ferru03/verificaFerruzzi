package com.example;

import java.io.*;
import java.net.*;

public class Server {
    ServerSocket server;
    Socket msocket;
    DataInputStream in;
    DataOutputStream out;

    public Socket attendi() {
        try {
            //creo il server sulla porta ****
            System.out.println("Server in esecuzione..");
            server = new ServerSocket(6789);

            //accetto eventuale connessione da parte del client
            msocket = server.accept();
            System.out.println("Client connesso con successo! ");

            //chiudo la connessione per evitare altre connessioni
            server.close();

            //inizializzo gli stream per consentire la comunicazione
            out = new DataOutputStream(msocket.getOutputStream());
            in = new DataInputStream(msocket.getInputStream());

        } catch (IOException e) {
            System.out.println(e.getMessage());
            System.out.println("Errore durante l'istanza del server");
            System.exit(1);
        }
        return msocket;
    }

    public void calcola(){
        try{
            int x;
            int y;
            int risultato = 0;
            //leggo la scelta e in base a quella eseguo le operazioni
            String scelta = in.readLine();

            //accetto prima i numeri
            x = in.read();
            System.out.println("primo numero: " + x);
            y = in.read();
            System.out.println("secondo numero: " + y);

            switch (scelta){
                case "Somma":
                    System.out.println("Scelta: " + scelta);
                    //somma
                    risultato = x + y;
                case "Sottrazione":
                    System.out.println("Scelta: " + scelta);
                    //sottrazione
                        risultato = x - y;
                case "Moltiplicazione":
                    System.out.println("Scelta: " + scelta);
                    //moltiplicazione
                    risultato = x * y;
                case "Divisione":
                System.out.println("Scelta: " + scelta);
                //moltiplicazione
                risultato = x / y;
            }
            System.out.println("Risultato: " + risultato);

        }catch (Exception e){
            System.out.println("Errore");
        }
    }
}
